// function capitalize(str) {
//   return str.charAt(0).toUpperCase() + str.slice(1);
// }

//module.exports = { capitalize };
async function hello() {
  const result1 = await new Promise((resolve) =>
    setTimeout(() => resolve("1"))
  );

  return result1;
}
console.log(hello());
